# $Id: README.txt,v 1.1.2.1 2010/12/22 02:57:19 kiam Exp $
#

This is the directory where the Textile library is looked for.
Version 7.x-2-0-rc8 and forward look for the Textile library also outside the
directory where the module is copied, such as
/sites/all/libraries/textile, or profiles/$profile/libraries/textile
(where $profile is the currently used profile).
